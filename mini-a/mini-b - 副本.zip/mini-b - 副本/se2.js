// server.js
const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs').promises;
const path = require('path');
const util = require('util');
const https = require('https');
const { exec } = require('child_process');
const execPromise = util.promisify(exec);
const gccPath = 'C:/msys64/ucrt64/bin/gcc.exe'; // 根据环境调整

const app = express();
const PORT = process.env.PORT || 3001;
const isHttpsEnabled = process.env.ENABLE_HTTPS === 'true';

// 日志输出函数
function log(message) {
    console.log(`[INFO] ${new Date().toISOString()} ${message}`);
}

// 错误日志输出函数
function errorLog(message) {
    console.error(`[ERROR] ${new Date().toISOString()} ${message}`);
}

// 中间件配置
app.use(bodyParser.json({ limit: '1mb' }));

// 重试删除文件或目录的最大次数
const MAX_RETRIES = 3;
// 重试间隔时间（毫秒）
const RETRY_DELAY = 1000;

// 递归清理临时文件和目录，并添加重试机制
async function cleanup(paths) {
    for (const p of paths) {
        let retries = 0;
        while (retries < MAX_RETRIES) {
            try {
                const stats = await fs.stat(p);
                if (stats.isDirectory()) {
                    const files = await fs.readdir(p);
                    await Promise.all(files.map(file => cleanup([path.join(p, file)])));
                    await fs.rmdir(p); // 使用 rmdir 而不是 rm
                    log(`Directory ${p} has been removed.`);
                } else {
                    await fs.unlink(p);
                    log(`File ${p} has been removed.`);
                }
                break; // 删除成功，退出重试循环
            } catch (err) {
                if (err.code !== 'ENOENT') { // 忽略文件不存在的错误
                    if (retries < MAX_RETRIES - 1) {
                        errorLog(`清理失败，尝试第 ${retries + 2} 次: ${p}`, err);
                        await new Promise(resolve => setTimeout(resolve, RETRY_DELAY));
                    } else {
                        errorLog(`清理失败，达到最大重试次数: ${p}`, err);
                    }
                } else {
                    break; // 文件不存在，退出重试循环
                }
            }
            retries++;
        }
    }
}

// 加载SSL证书（如果启用HTTPS）
async function loadCredentials() {
    if (!isHttpsEnabled) return null;
    try {
        const privateKeyPath = path.resolve(__dirname, 'ssl', 'private.key');
        const certificatePath = path.resolve(__dirname, 'ssl', 'certificate.crt');

        // 确保证书文件存在
        await fs.access(privateKeyPath);
        await fs.access(certificatePath);

        const privateKey = await fs.readFile(privateKeyPath, 'utf8');
        const certificate = await fs.readFile(certificatePath, 'utf8');

        return { key: privateKey, cert: certificate };
    } catch (err) {
        errorLog('Error reading SSL certificate files:', err);
        // 如果启用了HTTPS但证书加载失败，则尝试以HTTP启动而不是退出程序
        isHttpsEnabled = false;
        log('Falling back to HTTP due to SSL certificate loading failure.');
        return null;
    }
}


// 编译和运行C代码的路由
app.post('/compile', async (req, res) => {
    log('Received a /compile request');
    const userCode = req.body.code;
    const input = req.body.input || ''; // 新增 input 参数

    // 输入验证
    if (!userCode || typeof userCode !== 'string') {
        log('Invalid code provided');
        return res.status(400).json({ success: false, error: 'No code provided or invalid code format.' });
    }

    // 生成唯一的临时目录名，确保路径长度适中
    const uniqueId = `${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const tempDir = path.join(__dirname, 'temp', uniqueId);
    const tempCFile = path.join(tempDir, 'temp.c');
    const tempOutFile = path.join(tempDir, 'temp.exe'); // 修改为 .exe 以适应Windows平台

    try {
        // 创建临时目录并写入代码
        await fs.mkdir(tempDir, { recursive: true });
        await fs.writeFile(tempCFile, userCode, 'utf8');
        log(`Temporary C file created: ${tempCFile}`);

        // 编译代码，使用绝对路径并转义引号以防止注入
        const compileCommand = `"${gccPath}" "${tempCFile}" -o "${tempOutFile}" -Wall -Wextra 2>&1`;
        log(`Executing compilation command: ${compileCommand}`);
        const { stdout: compileStdout, stderr: compileStderr } = await execPromise(compileCommand);

        if (compileStderr) {
            errorLog('Compilation Error:', compileStderr.trim());
            return res.status(400).json({ success: false, error: `Compilation failed: ${compileStderr.trim()}` });
        }
        log('Compilation Successful:', compileStdout.trim());

        // 运行可执行文件，将 input 作为标准输入传递给程序
        const runCommand = `echo "${input.replace(/"/g, '\\"')}" | "${tempOutFile}" 2>&1`;
        log(`Executing run command: ${runCommand}`);
        const { stdout: runOutput, stderr: runStderr } = await execPromise(runCommand);

        if (runStderr) {
            errorLog('Runtime Error:', runStderr.trim());
            return res.status(500).json({ success: false, error: `Runtime error: ${runStderr.trim()}` });
        }
        log('Program Output:', runOutput.trim());

        // 发送响应
        res.status(200).json({ success: true, output: runOutput.trim() });

    } catch (error) {
        errorLog('Error during compilation or execution:', error.message);
        res.status(500).json({ success: false, error: `Error during compilation or execution: ${error.message}` });
    } finally {
        // 清理临时文件和目录
        try {
            await cleanup([tempDir]);
            log(`Temporary files and directory cleaned up: ${tempDir}`);
        } catch (cleanupError) {
            errorLog('Failed to clean up temporary files and directory:', cleanupError.message);
        }
    }
});

// 启动服务器
(async () => {
    let server;
    const credentials = isHttpsEnabled ? await loadCredentials() : null;

    try {
        if (isHttpsEnabled && credentials) {
            server = https.createServer(credentials, app);
            log(`Starting HTTPS server on port ${PORT}`);
        } else {
            server = app.listen(PORT, () => {
                log(`Starting HTTP server on port ${PORT}`);
            });
        }

        server.on('listening', () => {
            if (isHttpsEnabled) {
                log(`HTTPS server is running on port ${PORT}`);
            } else {
                log(`HTTP server is running on port ${PORT}`);
            }
        });
    } catch (error) {
        errorLog('Error starting the server:', error);
        process.exit(1);
    }
})();