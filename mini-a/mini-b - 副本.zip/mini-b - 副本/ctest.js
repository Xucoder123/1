const https = require('https');
const http = require('http');
const numRequests = 10; // 并发请求的数量
const url = 'http://localhost:3001/compile'; // 替换为你的服务器地址和路由

// 要发送的请求数据
const postData = JSON.stringify({
    code: '#include <stdio.h>\nint main() {\n    printf("Hello, World!\\n");\n    return 0;\n}',
    input: ''
});

// 选项配置
const options = {
    hostname: 'localhost',
    port: 3001,
    path: '/compile',
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(postData)
    }
};

// 发起单个请求的函数
function sendRequest() {
    const req = (options.port === 443 ? https : http).request(options, (res) => {
        let data = '';

        res.on('data', (chunk) => {
            data += chunk;
        });

        res.on('end', () => {
            console.log(`Response status code: ${res.statusCode}`);
            console.log(`Response body: ${data}`);
        });
    });

    req.on('error', (error) => {
        console.error(`Request error: ${error.message}`);
    });

    req.write(postData);
    req.end();
}

// 发起多个并发请求
for (let i = 0; i < numRequests; i++) {
    sendRequest();
}