const express = require('express');
const fs = require('fs');
const path = require('path');
const app = express();
const port = process.env.PORT || 3001;

// 解析 JSON 格式的请求体，并限制请求体大小以防止过大的负载
app.use(express.json({ limit: '1mb' }));

// 定义临时目录路径
const tempDir = path.join(__dirname, 'temp');

// 异步创建 temp 目录（如果不存在）
fs.mkdir(tempDir, { recursive: true }, (err) => {
  if (err) {
    console.error('Failed to create temp directory:', err);
    process.exit(1); // 无法创建目录则退出程序
  }
});

// 中间件：错误处理
app.use((err, req, res, next) => {
  console.error('An error occurred:', err);
  res.status(500).send('Internal Server Error');
});

app.post('/compile', async (req, res) => {
  try {
    // 获取请求头和请求体
    const headers = req.headers;
    const body = req.body;

    // 构建文件路径
    const filePath = path.join(tempDir, 'request.txt');

    // 写入文件内容，使用异步方式避免阻塞
    const data = `Headers: ${JSON.stringify(headers, null, 2)}\nBody: ${JSON.stringify(body, null, 2)}`;
    fs.promises.writeFile(filePath, data, 'utf8')
      .then(() => {
        console.log('Request saved to file successfully.');
        res.status(200).send('Request received and saved to file.');
      })
      .catch((writeErr) => {
        console.error('Error writing file:', writeErr);
        res.status(500).send('Failed to save request to file.');
      });
  } catch (error) {
    console.error('Error processing /compile route:', error);
    res.status(500).send('Internal Server Error');
  }
});

app.get('/', (req, res) => {
  res.status(200).send('Hello World!');
});

// 启动服务器并监听指定端口
app.listen(port, '0.0.0.0', () => {
  console.log(`Server is running on http://localhost:${port}`);
});
