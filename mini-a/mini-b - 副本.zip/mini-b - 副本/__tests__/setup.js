// __tests__/setup.js
jest.setTimeout(20000); // 全局设置超时时间