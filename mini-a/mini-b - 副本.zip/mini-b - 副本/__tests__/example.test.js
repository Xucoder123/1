// __tests__/example.test.js
const http = require('http');
const request = require('supertest');
const fs = require('fs');
const path = require('path');
const os = require('os');

// 获取一个可用的端口
let port = 3001;


describe('POST /compile', () => {
  let app;
  let server;
  const tempDir = path.join(__dirname, '..', 'temp');

  // 在所有测试前启动服务器
  beforeAll(async () => {
    // 确保不模拟fs模块，让测试使用真实文件系统
    // jest.doMock('fs') 已移除

    jest.resetModules();
    app = require('../server2.js');

    // 获取可用端口
    const port = await getAvailablePort();

    // 启动服务器并保存引用，以便后续关闭
    server = app.listen(port, () => {
      console.log(`Server is running on port ${server.address().port}`);
    });

    // 等待服务器完全启动
    await new Promise((resolve) => {
      server.once('listening', resolve);
    });
  });

  // 在所有测试后关闭服务器
  afterAll(async () => {
    if (server) {
      await new Promise((resolve, reject) => {
        server.close(resolve);
      });
      console.log('Server has been closed.');
    }
  });
process.on('SIGINT', () => {
    server.close(() => {
        console.log('Server closed');
        process.exit();
    });
});


  // 获取可用端口
  function getAvailablePort() {
    return new Promise((resolve) => {
      const port = 3001; // 默认端口
      const testServer = app.listen(port);
      testServer.on('error', (err) => {
        if (err.code === 'EADDRINUSE') {
          console.warn(`Port ${port} is in use, trying to find an available port...`);
          app.set('port', 0); // 让系统自动分配可用端口
          const dynamicServer = app.listen(0);
          dynamicServer.on('listening', () => {
            const assignedPort = dynamicServer.address().port;
            resolve(assignedPort);
            dynamicServer.close();
          });
        } else {
          reject(err);
        }
      });
      testServer.on('listening', () => {
        resolve(port);
        testServer.close();
      });
    });
  }

  // 测试用例分组：基本功能
  describe('Basic Functionality', () => {
    // 测试有效C代码
    it('should compile and run valid C code', async () => {
      const response = await request(app)
        .post('/compile')
        .send({ code: '#include <stdio.h>\nint main() { printf("Hello, World!\\n"); return 0; }' });

      expect(response.statusCode).toBe(200);
      expect(response.body).toHaveProperty('success', true);
      expect(response.body).toHaveProperty('output', 'Hello, World!\n');
    });

    // 测试带参数的C代码
    it('should handle command-line arguments', async () => {
      const response = await request(app)
        .post('/compile')
        .send({ code: `
          #include <stdio.h>
          int main(int argc, char *argv[]) {
            printf("Arguments: %d\\n", argc);
            for (int i = 0; i < argc; i++) {
              printf("argv[%d]: %s\\n", i, argv[i]);
            }
            return 0;
          }
        ` });

      expect(response.statusCode).toBe(200);
      expect(response.body.output).toContain('Arguments: 1');
    });
  });

  // 测试用例分组：错误处理
  describe('Error Handling', () => {
    // 测试无效C代码
    it('should handle invalid C code', async () => {
      const response = await request(app)
        .post('/compile')
        .send({ code: 'invalid code' });

      expect(response.statusCode).toBe(400); // 修正为400，与代码一致
      expect(response.body).toHaveProperty('success', false);
      expect(response.body.error).toContain('Compilation Error');
    });

    // 测试空输入
    it('should reject empty code', async () => {
      const response = await request(app)
        .post('/compile')
        .send({ code: '' });

      expect(response.statusCode).toBe(400);
      expect(response.body.error).toContain('No code provided');
    });

    // 测试无输入
    it('should handle missing code parameter', async () => {
      const response = await request(app)
        .post('/compile')
        .send({});

      expect(response.statusCode).toBe(400);
      expect(response.body.error).toContain('No code provided');
    });

    // 测试非字符串输入
    it('should handle non-string code input', async () => {
      const response = await request(app)
        .post('/compile')
        .send({ code: 123 });

      expect(response.statusCode).toBe(400);
      expect(response.body.error).toContain('invalid code format');
    });
  });

  // 测试用例分组：安全控制
  describe('Security Control', () => {
    // 测试无限循环（验证超时机制）
    it('should timeout on infinite loop', async () => {
      const response = await request(app)
        .post('/compile')
        .send({ code: '#include <stdio.h>\nint main() { while(1); return 0; }' });

      expect(response.statusCode).toBe(400);
      expect(response.body.error).toContain('Runtime Error');
      expect(response.body.error).toContain('timed out');
    });

    // 测试文件访问（安全沙箱）
    it('should prevent file system access', async () => {
      const response = await request(app)
        .post('/compile')
        .send({ code: `
          #include <stdio.h>
          int main() {
            FILE *fp = fopen("package.json", "r");
            if (fp) {
              printf("File access successful\\n");
              fclose(fp);
            } else {
              printf("File access failed\\n");
            }
            return 0;
          }
        ` });

      expect(response.statusCode).toBe(200);
      // 假设沙箱环境下无法访问文件
      expect(response.body.output).toContain('File access failed');
    });
  });

  // 测试用例分组：性能和资源限制
  describe('Performance & Resource Limits', () => {
    // 测试大内存占用
    it('should handle large memory allocation', async () => {
      const response = await request(app)
        .post('/compile')
        .send({ code: `
          #include <stdio.h>
          #include <stdlib.h>
          int main() {
            // 尝试分配1GB内存（可能导致系统限制或超时）
            void *ptr = malloc(1024 * 1024 * 1024); // 1GB
            if (ptr) {
              printf("Memory allocated\\n");
              free(ptr);
            } else {
              printf("Memory allocation failed\\n");
            }
            return 0;
          }
        ` });

      expect(response.statusCode).toBe(400);
      expect(response.body.error).toContain('Runtime Error');
    });

    // 测试长时间运行
    it('should timeout on long-running process', async () => {
      const response = await request(app)
        .post('/compile')
        .send({ code: `
          #include <stdio.h>
          #include <unistd.h>
          int main() {
            sleep(15); // 睡眠15秒，超过默认10秒超时
            printf("Done\\n");
            return 0;
          }
        ` });

      expect(response.statusCode).toBe(400);
      expect(response.body.error).toContain('timed out');
    });
  });

  // 测试用例分组：文件系统清理
  describe('Temporary File Cleanup', () => {
    // 验证临时文件被清理
    it('should clean up temporary files after execution', async () => {
      // 确保临时目录存在且为空
      await clearDirectory(tempDir);

      await request(app)
        .post('/compile')
        .send({ code: '#include <stdio.h>\nint main() { return 0; }' });

      // 验证临时目录不存在或为空
      const exists = fs.existsSync(tempDir);
      const files = fs.readdirSync(tempDir);
      expect(exists).toBe(true); // 根据实际需求调整预期值
      expect(files.length).toBe(0); // 确保目录为空
    });
  });

  // 辅助函数：清空目录内容
  function clearDirectory(directoryPath) {
    return new Promise((resolve, reject) => {
      fs.rmdir(directoryPath, { recursive: true }, (err) => {
        if (err && err.code !== 'ENOENT') { // 如果目录不存在则忽略错误
          reject(err);
        } else {
          // 重新创建空目录以避免 ENOENT 错误
          fs.mkdir(directoryPath, { recursive: true }, (mkdirErr) => {
            if (mkdirErr) {
              reject(mkdirErr);
            } else {
              resolve();
            }
          });
        }
      });
    });
  }
});
afterAll(async () => {
  if (server) {
    await new Promise((resolve, reject) => {
      server.close((err) => {
        if (err) {
          reject(err);
        } else {
          resolve();
        }
      });
    });
    console.log('Server has been closed.');
  }
});