// jest.config.js
module.exports = {
  transform: {
    '^.+\\.(js|mjs)$': 'babel-jest', // 同时处理 .js 和 .mjs 文件
  },
  // 排除微信开发者工具目录中的冲突文件
  modulePathIgnorePatterns: [
    "<rootDir>/AppData/",
    "<rootDir>/node_modules/", // 通常也需要排除
  ],
  // 配置测试文件匹配规则
  testMatch: [
    "**/__tests__/**/*.test.js",
    "**/*.spec.js",
  ],
};