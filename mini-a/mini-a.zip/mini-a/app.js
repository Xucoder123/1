// app.js

App({
    globalData: {
        // 将服务器地址作为全局变量，方便统一修改
        serverUrl: 'http://localhost:3001'
    },
    
    onLaunch: async function () {
        await this.checkAndCreateLogDir();
        this.startServiceDiscovery();
        // 其他初始化代码...
    },

    checkAndCreateLogDir: async function () {
        const fs = wx.getFileSystemManager();
        const logDir = `${wx.env.USER_DATA_PATH}/miniprogramLog/`;

        try {
            await fs.access({ path: logDir });
            console.log('日志目录已存在');
        } catch (err) {
            if (err.errno === -1) { // 目录不存在的情况
                try {
                    await fs.mkdir({ path: logDir, recursive: true });
                    console.log('日志目录创建成功');
                } catch (mkdirErr) {
                    console.error('创建日志目录失败：', mkdirErr);
                }
            } else {
                console.error('检查目录失败：', err.errMsg);
            }
        }
    },

    startServiceDiscovery: function () {
        wx.startLocalServiceDiscovery({
            serviceType: '_http._tcp',
            success: (res) => {
                console.log('服务发现成功', res);
            },
            fail: (err) => {
                console.error('服务发现失败', err);
            }
        });
    },
    
    // 修复后的API调用方法
    callApi: function (code) {
        const apiParams = {
            url: `${this.globalData.serverUrl}/compile`,
            method: 'POST',
            data: {
                code: code
            },
            dataType: 'json',
            header: {
                'Content-Type': 'application/json'
            },
            success: function (res) {
                console.log('API 调用成功:', res.data);
                // 处理成功响应
            },
            fail: function (err) {
                console.error('API 调用失败:', err);
                // 处理失败响应
            }
        };

        console.log('API参数：', apiParams);
        wx.request(apiParams);
    }
});
        // 在这里调用实际的API
       
        // 3. 发送编译请求（避免在 onLaunch 中发送网络请求，建议移至页面逻辑）
        // 此部分代码已移除，建议在具体页面中处理

    


  

