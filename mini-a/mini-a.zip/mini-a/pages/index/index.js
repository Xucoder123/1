// pages/index/index.js
Page({
  data: {
    // 初始化 code 为示例代码
    code: `#include <stdio.h>\n\nint main() {\n    printf("Hello World!\\n");\n    return 0;\n}`,
    history: [],
    output: '',
    currentIndex: -1,
    isHistoryExpanded: false, // 控制历史记录折叠状态
    isCompiling: false, // 标记是否正在编译，防止重复点击
    input: '', // 添加 input 字段用于编译输入
  },

  handleInput(e) {
    this.setData({ code: e.detail.value });
  },

  addToHistory(newCode) {
    const { history, currentIndex } = this.data;
    if (currentIndex !== -1) {
      const updatedHistory = [...history];
      // 如果当前代码已经在历史记录中，先移除后续的记录
      const index = updatedHistory.findIndex(code => code === newCode);
      if (index !== -1) {
        updatedHistory.splice(index + 1);
      } else {
        updatedHistory.splice(currentIndex + 1);
      }
      updatedHistory.push(newCode);
      this.setData({ history: updatedHistory, currentIndex: updatedHistory.length - 1 });
    } else {
      // 检查新代码是否已存在于历史记录中，避免重复
      const index = this.data.history.findIndex(code => code === newCode);
      if (index === -1) {
        this.setData({ history: [newCode], currentIndex: 0 });
      } else {
        this.setData({ currentIndex: index });
      }
    }
  },

  undo() {
    const { currentIndex, history } = this.data;
    if (currentIndex > 0) {
      this.setData({
        code: history[currentIndex - 1],
        currentIndex: currentIndex - 1,
        output: '', // 清空输出，等待重新编译
      });
    } else {
      wx.showToast({ title: '已是最早版本', icon: 'none' });
    }
  },

  redo() {
    const { currentIndex, history } = this.data;
    if (currentIndex < history.length - 1) {
      this.setData({
        code: history[currentIndex + 1],
        currentIndex: currentIndex + 1,
        output: '', // 清空输出，等待重新编译
      });
    } else {
      wx.showToast({ title: '已是最新版本', icon: 'none' });
    }
  },

  // 这里添加 compileCode 函数
  async compileCode() {
    const { code, input, isCompiling } = this.data;
    if (isCompiling) {
      wx.showToast({ title: '编译中，请稍候', icon: 'none' });
      return;
    }

    this.setData({ isCompiling: true });
    wx.showLoading({ title: '编译中...' });
    try {
      console.log('Sending code:', code);
      console.log('Sending input:', input);
      const response = await new Promise((resolve, reject) => {
        wx.request({
          url: 'http://localhost:3001/compile', // 修改为实际的服务器地址
          method: 'POST',
          data: {
            code,
            input, // 确保 input 被正确发送
          },
          header: { 'Content-Type': 'application/json' },
          timeout: 10000, // 设置超时时间
          success: resolve,
          fail: reject,
        });
      });

      if (response && response.statusCode === 200) {
        const data = response.data;
        if (data.success) {
          console.log('编译成功，输出：', data.output);
          this.setData({ output: data.output || '编译成功，无输出。' });
          this.addToHistory(code); // 将当前代码添加到历史记录
          return data.output;
        } else {
          console.error('编译失败，错误信息：', data.error);
          this.setData({ output: `编译失败：${data.error}` });
          throw new Error(`编译失败：${data.error}`);
        }
      } else {
        const errorData = response && response.data || {};
        const errorMessage = errorData.error || `编译失败，状态码：${response ? response.statusCode : '未知'}`;
        console.error('编译失败，状态码：', response ? response.statusCode : '未知', '，响应数据：', errorData);
        this.setData({ output: `编译失败：${errorMessage}` });
        throw new Error(`编译失败，状态码：${response ? response.statusCode : '未知'}，错误信息：${errorMessage}`);
      }
    } catch (error) {
      console.error('请求出错：', error);
      this.setData({ output: `编译失败：${error.message || '未知错误'}` });
      wx.showToast({ title: '编译失败', icon: 'none' });
    } finally {
      this.setData({ isCompiling: false });
      wx.hideLoading();
    }
  },

  selectHistory(e) {
    const index = e.currentTarget.dataset.index;
    this.setData({
      code: this.data.history[index],
      currentIndex: index,
      output: '', // 清空输出，等待重新编译
    });
  },

  toggleHistory() {
    this.setData({
      isHistoryExpanded: !this.data.isHistoryExpanded,
    });
  },
});
